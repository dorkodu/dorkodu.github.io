import{j as e,F as t,T as o,a as r,b as a,l as n}from"./index-DsG9ra32.js";import{S as i}from"./Stack-CMXgN1rd.js";import{c as s}from"./createReactComponent-DdX_Sv7I.js";/**
 * @license @tabler/icons-react v3.2.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var l=s("outline","arrow-right","IconArrowRight",[["path",{d:"M5 12l14 0",key:"svg-0"}],["path",{d:"M13 18l6 -6",key:"svg-1"}],["path",{d:"M13 6l6 6",key:"svg-2"}]]);function h(){return e.jsxs(i,{maw:460,mx:"auto",p:10,mt:"5vw",mb:"10vw",children:[e.jsxs(t,{direction:"column",align:"center",children:[e.jsx(o,{fw:900,fz:"15vw",c:"dimmed",opacity:.25,lh:1,children:"404"}),e.jsx(o,{fw:900,lh:1,lts:-1,children:"Not Found"})]}),e.jsx(r,{size:"xl",maw:460,ta:"center",mx:"auto",lh:1.25,children:"The page you are looking for was moved, removed, renamed or may have never existed."}),e.jsx(a,{component:n,to:"/",size:"lg",radius:"lg",rightSection:e.jsx(l,{}),children:"Go Back Home"})]})}export{h as default};
