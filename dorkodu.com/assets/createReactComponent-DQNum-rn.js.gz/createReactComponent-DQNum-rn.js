import{o as e}from"./index-C7r0trfs.js";/**
 * @license @tabler/icons-react v3.2.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */var p={outline:{xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"},filled:{xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"currentColor",stroke:"none"}};/**
 * @license @tabler/icons-react v3.2.0 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */const g=(r,s,a,l)=>{const o=e.forwardRef(({color:n="currentColor",size:i=24,stroke:w=2,className:c,children:t,...h},m)=>e.createElement("svg",{ref:m,...p[r],width:i,height:i,className:["tabler-icon",`tabler-icon-${s}`,c].join(" "),...r==="filled"?{fill:n}:{strokeWidth:w,stroke:n},...h},[...l.map(([d,f])=>e.createElement(d,f)),...Array.isArray(t)?t:[t]]));return o.displayName=`${a}`,o};export{g as c};
